import 'dotenv/config';
import { createClient } from '@supabase/supabase-js';

const url = process.env.SUPABASE_URL;
const anonKey = process.env.SUPABASE_ANON_KEY;
if (!url || !anonKey) throw new Error('Configure SUPABASE_URL e SUPABASE_ANON_KEY no arquivo .env');

// O cliente usa a chave pública e encaminha o JWT do usuário para respeitar as políticas RLS.
export const supabase = createClient(url, anonKey, {
  auth: { autoRefreshToken: false, persistSession: false, detectSessionInUrl: false },
});
